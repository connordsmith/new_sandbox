from python.data import load,dump



#import_train_file = './good_droptols.data'
#train_columns = load(import_train_file)

#export_train_file = './ternary_droptols.data'
#dump(train_columns[1], export_train_file)

import_train_file = './three_classes.data'
train_columns = load(import_train_file)

export_train_file = './ternary_iso.data'
dump(train_columns[1], export_train_file)



#import_train_file = './el_edge_low.data'
#train_columns = load(import_train_file)

#export_train_file = './low_mean.data'
#dump(train_columns[1], export_train_file)

#import_train_file = './el_edge_high.data'
#train_columns = load(import_train_file)

#export_train_file = './high_mean.data'
#dump(train_columns[1], export_train_file)

#import_train_file = './droptols/drop_tol_0.001.data'
#train_columns = load(import_train_file)

#export_train_file = '0.001.data'
#dump(train_columns[1], export_train_file)

#import_train_file = './droptols/drop_tol_0.025.data'
#train_columns = load(import_train_file)

#export_train_file = '0.025.data'
#dump(train_columns[1], export_train_file)

#import_train_file = './droptols/drop_tol_0.0.data'
#train_columns = load(import_train_file)

#export_train_file = '0.0.data'
#dump(train_columns[1], export_train_file)

#import_train_file = './droptols/drop_tol_0.005.data'
#train_columns = load(import_train_file)

#export_train_file = '0.005.data'
#dump(train_columns[1], export_train_file)

#import_train_file = './droptols/drop_tol_0.05.data'
#train_columns = load(import_train_file)

#export_train_file = '0.05.data'
#dump(train_columns[1], export_train_file)

#import_train_file = './droptols/drop_tol_0.1.data'
#train_columns = load(import_train_file)

#export_train_file = '0.1.data'
#dump(train_columns[1], export_train_file)

#import_train_file = './droptols/drop_tol_0.01.data'
#train_columns = load(import_train_file)

#export_train_file = '0.01.data'
#dump(train_columns[1], export_train_file)

#import_train_file = './droptols/drop_tol_0.075.data'
#train_columns = load(import_train_file)

#export_train_file = '0.075.data'
#dump(train_columns[1], export_train_file)
